﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using K4os.Compression.LZ4.Internal;
using MySql.Data.MySqlClient;

namespace CalendarApp
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            this.CenterToScreen();

            backButton.Size = new Size(75, 23);  
        
            panel.Dock = DockStyle.Fill;
            panel.AutoScroll = true;
            panel.FlowDirection = FlowDirection.TopDown;
            panel.WrapContents = false;


            showEvents();
        }

        void showEvents()
        {
            panel.Controls.Clear();

            string connStr = "server=csitmariadb.eku.edu;user=student;database=csc340_db;port=3306;password=Maroon@21?";


            MySql.Data.MySqlClient.MySqlConnection conn = new MySql.Data.MySqlClient.MySqlConnection(connStr);

            conn.Open();

            string query = "SELECT ID, Name, Start, End FROM noelFeltnerReichert_calendarNew ORDER BY Start ASC";
            MySqlCommand cmd = new MySqlCommand(query, conn);
            MySqlDataReader reader = cmd.ExecuteReader();

            int lastYear = 0;
            int lastMonth = 0;

            while (reader.Read())
            {
                int eventId = reader.GetInt32("ID");
                string eventName = reader.GetString("Name");
                DateTime start = reader.GetDateTime("Start");
                DateTime end = reader.GetDateTime("End"); ;

                //output years and dates as events are output in order
                if (start.Year != lastYear)
                {
                    lastYear = start.Year;
                    Label yearLabel = new Label();
                    yearLabel.Text = start.Year.ToString();
                    yearLabel.Font = new Font("Arial", 20, FontStyle.Bold);
                    yearLabel.AutoSize = true;
                    panel.Controls.Add(yearLabel);
                }

                if (start.Month != lastMonth || start.Year != lastYear)
                {
                    lastMonth = start.Month;
                    Label monthLabel = new Label();
                    monthLabel.Text = start.ToString("MMMM");
                    monthLabel.Font = new Font("Arial", 16);
                    monthLabel.AutoSize = true;
                    panel.Controls.Add(monthLabel);
                }



                Panel eventPanel = new Panel();
                eventPanel.AutoSize = true;
                eventPanel.Padding = new Padding(5);

                Label detailLabel = new Label();
                detailLabel.Text = $"{eventName}:";
                detailLabel.AutoSize = true;
                detailLabel.Margin = new Padding(3, 3, 3, 0);
                //detailLabel.ForeColor = Color.Blue;
                detailLabel.Font = new Font("Arial", 12);

                Button btn = new Button();
                btn.Text = $"Start: {start:MMM dd, yyyy hh: mm: ss tt}"
                    + Environment.NewLine + $"End: {end: MMM dd, yyyy hh: mm: ss tt}"
                    + Environment.NewLine + Environment.NewLine + "Click To View Details";
                btn.TextAlign = ContentAlignment.MiddleLeft;
                btn.Tag = eventId;
                btn.AutoSize = true;
                btn.Height = 50;
                btn.AutoSizeMode = AutoSizeMode.GrowAndShrink;
                btn.Click += (sender, e) =>
                {
                    eventDetails details = new eventDetails((int)((Button)sender).Tag);
                    this.Hide();
                    details.ShowDialog();
                    this.Show();
                    showEvents();
                };
                panel.Controls.Add(detailLabel);
                panel.Controls.Add(btn);
            }
        }

        private void panel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void backButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
