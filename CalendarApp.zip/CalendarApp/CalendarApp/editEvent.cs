﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CalendarApp
{
    public partial class editEvent : Form
    {
        string startDay;
        string endDay;
        int eventId;

        public editEvent(int eventId, DateTime st, DateTime en, string name, string desc)
        {
            InitializeComponent();
            this.CenterToScreen();
            eventTitleBox.Text = name;
            startTime.Value = st;
            startDay = st.ToString();
            endTime.Value = en;
            endDay = en.ToString();
            descriptionBox.Text = desc;
            this.eventId = eventId;
            chosenStartDay.Text = st.ToString("MMM dd, yyyy hh:mm:ss tt");
            chosenEndDay.Text = en.ToString("MMM dd, yyyy hh:mm:ss tt");
        }

        private void startTime_ValueChanged(object sender, EventArgs e)
        {
            chosenStartDay.Text = startTime.Value.ToString("MMM dd, yyyy hh:mm:ss tt");
        }

        private void endTime_ValueChanged(object sender, EventArgs e)
        {
            chosenEndDay.Text = endTime.Value.ToString("MMM dd, yyyy hh:mm:ss tt");
        }

        private void confirmButton_Click(object sender, EventArgs e)
        {
            string connStr = "server=csitmariadb.eku.edu;user=student;database=csc340_db;port=3306;password=Maroon@21?";


            MySql.Data.MySqlClient.MySqlConnection conn = new MySql.Data.MySqlClient.MySqlConnection(connStr);

            conn.Open();
            if (endTime.Value <= startTime.Value && String.IsNullOrEmpty(eventTitleBox.Text))
            {
                MessageBox.Show("End time must be greater than start time.\nEvent must have title.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            if (endTime.Value <= startTime.Value)
            {
                MessageBox.Show("End time must be greater than start time.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            if (String.IsNullOrEmpty(eventTitleBox.Text))
            {
                MessageBox.Show("Event must have title.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            else
            {
                string query = @"SELECT Name, Start, End FROM noelFeltnerReichert_calendarNew
                            WHERE NOT (`Start` >= @NewEventEnd OR `End` <= @NewEventStart)
                            AND ID != @EventId";
                DateTime st = startTime.Value;
                DateTime en = endTime.Value;
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@NewEventStart", st);
                cmd.Parameters.AddWithValue("@NewEventEnd", en);
                cmd.Parameters.AddWithValue("@EventId", eventId);

                string overlapping = null;
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        if (overlapping == null)
                            overlapping = "";
                        overlapping += ($"Event: {reader["Name"]}, Start: {Convert.ToDateTime(reader["Start"]).ToString("g")}, End: {Convert.ToDateTime(reader["End"]).ToString("g")}\n");
                    }
                }

                if (!string.IsNullOrEmpty(overlapping))
                {
                    MessageBox.Show($"Cannot update event due to overlapping with the following event(s):\n{overlapping}", "Scheduling Conflict", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                TimeSpan dur = endTime.Value - startTime.Value;
                int hours = (int)dur.TotalHours;
                int minutes = dur.Minutes;
                int seconds = dur.Seconds;
                string message = $"Event Name: {eventTitleBox.Text}\nStart Time: {startDay}\nEnd Time: {endDay}\nDuration: {hours} hours, {minutes} minutes and {seconds} seconds.\n\nDo you want to confirm this event?";
                DialogResult confirmEvent = MessageBox.Show(message, "Update Event", MessageBoxButtons.YesNo);

                if (confirmEvent == DialogResult.Yes)
                {
                    string updateQuery = @"UPDATE noelFeltnerReichert_calendarNew 
                       SET Name = @Name, Start = @Start, End = @End, Description = @Description 
                       WHERE ID = @EventId";
                    MySqlCommand cma = new MySqlCommand(updateQuery, conn);
                    cma.Parameters.AddWithValue("@Name", eventTitleBox.Text);
                    cma.Parameters.AddWithValue("@Start", st);
                    cma.Parameters.AddWithValue("@End", en);
                    cma.Parameters.AddWithValue("@Description", descriptionBox.Text);
                    cma.Parameters.AddWithValue("@EventId", eventId);
                    cma.ExecuteNonQuery();
                    conn.Close();

                    //close the window after successfully saved
                    MessageBox.Show("Event successfully updated.");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Event not updated.");
                }
            }
        }

        private void editEvent_Load(object sender, EventArgs e)
        {

        }

        private void backButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
