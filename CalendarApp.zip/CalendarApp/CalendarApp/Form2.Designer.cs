﻿namespace CalendarApp
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            startTime = new DateTimePicker();
            endTime = new DateTimePicker();
            label1 = new Label();
            label2 = new Label();
            addToCalendarButton = new Button();
            eventTitle = new Label();
            eventTitleBox = new TextBox();
            label3 = new Label();
            descriptionBox = new TextBox();
            label4 = new Label();
            label5 = new Label();
            chosenStartDay = new Label();
            chosenEndDay = new Label();
            backButton = new Button();
            SuspendLayout();
            // 
            // startTime
            // 
            startTime.Format = DateTimePickerFormat.Time;
            startTime.Location = new Point(18, 137);
            startTime.Name = "startTime";
            startTime.Size = new Size(227, 23);
            startTime.TabIndex = 1;
            startTime.ValueChanged += startTime_ValueChanged;
            // 
            // endTime
            // 
            endTime.Format = DateTimePickerFormat.Time;
            endTime.Location = new Point(251, 137);
            endTime.Name = "endTime";
            endTime.Size = new Size(225, 23);
            endTime.TabIndex = 2;
            endTime.ValueChanged += endTime_ValueChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(18, 119);
            label1.Name = "label1";
            label1.Size = new Size(63, 15);
            label1.TabIndex = 3;
            label1.Text = "Start Time:";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(251, 119);
            label2.Name = "label2";
            label2.Size = new Size(59, 15);
            label2.TabIndex = 4;
            label2.Text = "End Time:";
            // 
            // addToCalendarButton
            // 
            addToCalendarButton.BackColor = SystemColors.Control;
            addToCalendarButton.FlatStyle = FlatStyle.System;
            addToCalendarButton.Font = new Font("Segoe UI", 12F);
            addToCalendarButton.ForeColor = SystemColors.Control;
            addToCalendarButton.Location = new Point(18, 204);
            addToCalendarButton.Name = "addToCalendarButton";
            addToCalendarButton.Size = new Size(458, 47);
            addToCalendarButton.TabIndex = 5;
            addToCalendarButton.Text = "Add to Calendar";
            addToCalendarButton.UseVisualStyleBackColor = false;
            addToCalendarButton.Click += addToCalendarButton_Click;
            // 
            // eventTitle
            // 
            eventTitle.AutoSize = true;
            eventTitle.Location = new Point(18, 47);
            eventTitle.Name = "eventTitle";
            eventTitle.Size = new Size(64, 15);
            eventTitle.TabIndex = 6;
            eventTitle.Text = "Event Title:";
            // 
            // eventTitleBox
            // 
            eventTitleBox.Location = new Point(18, 65);
            eventTitleBox.Name = "eventTitleBox";
            eventTitleBox.Size = new Size(227, 23);
            eventTitleBox.TabIndex = 7;
            eventTitleBox.TextChanged += eventTitleBox_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(251, 47);
            label3.Name = "label3";
            label3.Size = new Size(70, 15);
            label3.TabIndex = 8;
            label3.Text = "Description:";
            // 
            // descriptionBox
            // 
            descriptionBox.Location = new Point(251, 65);
            descriptionBox.MaxLength = 200;
            descriptionBox.Multiline = true;
            descriptionBox.Name = "descriptionBox";
            descriptionBox.ScrollBars = ScrollBars.Vertical;
            descriptionBox.Size = new Size(225, 41);
            descriptionBox.TabIndex = 9;
            descriptionBox.TextChanged += descriptionBox_TextChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(18, 172);
            label4.Name = "label4";
            label4.Size = new Size(77, 15);
            label4.TabIndex = 10;
            label4.Text = "Chosen Start:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(251, 172);
            label5.Name = "label5";
            label5.Size = new Size(73, 15);
            label5.TabIndex = 11;
            label5.Text = "Chosen End:";
            // 
            // chosenStartDay
            // 
            chosenStartDay.AutoSize = true;
            chosenStartDay.Location = new Point(101, 172);
            chosenStartDay.Name = "chosenStartDay";
            chosenStartDay.Size = new Size(38, 15);
            chosenStartDay.TabIndex = 12;
            chosenStartDay.Text = "label6";
            // 
            // chosenEndDay
            // 
            chosenEndDay.AutoSize = true;
            chosenEndDay.Location = new Point(330, 172);
            chosenEndDay.Name = "chosenEndDay";
            chosenEndDay.Size = new Size(38, 15);
            chosenEndDay.TabIndex = 13;
            chosenEndDay.Text = "label7";
            // 
            // backButton
            // 
            backButton.ForeColor = Color.Red;
            backButton.Location = new Point(401, 12);
            backButton.Name = "backButton";
            backButton.Size = new Size(75, 23);
            backButton.TabIndex = 14;
            backButton.Text = "Back";
            backButton.UseVisualStyleBackColor = true;
            backButton.Click += backButton_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(494, 265);
            Controls.Add(backButton);
            Controls.Add(chosenEndDay);
            Controls.Add(chosenStartDay);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(descriptionBox);
            Controls.Add(label3);
            Controls.Add(eventTitleBox);
            Controls.Add(eventTitle);
            Controls.Add(addToCalendarButton);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(endTime);
            Controls.Add(startTime);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Form2";
            Text = "Add Event";
            Load += Form2_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        public DateTimePicker startTime;
        public DateTimePicker endTime;
        private Label label1;
        private Label label2;
        public Button addToCalendarButton;
        private Label eventTitle;
        public TextBox eventTitleBox;
        private Label label3;
        public TextBox descriptionBox;
        private Label label4;
        private Label label5;
        private Label chosenStartDay;
        private Label chosenEndDay;
        private Button backButton;
    }
}