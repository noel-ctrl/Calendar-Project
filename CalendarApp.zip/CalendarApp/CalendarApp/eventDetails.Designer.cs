﻿namespace CalendarApp
{
    partial class eventDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            name = new Label();
            start = new Label();
            end = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            duration = new Label();
            label5 = new Label();
            description = new Label();
            descBox = new TextBox();
            editButton = new Button();
            deleteButton = new Button();
            backButton = new Button();
            SuspendLayout();
            // 
            // name
            // 
            name.AutoSize = true;
            name.Location = new Point(90, 47);
            name.Name = "name";
            name.Size = new Size(38, 15);
            name.TabIndex = 0;
            name.Text = "label1";
            // 
            // start
            // 
            start.AutoSize = true;
            start.Location = new Point(90, 91);
            start.Name = "start";
            start.Size = new Size(38, 15);
            start.TabIndex = 1;
            start.Text = "label2";
            // 
            // end
            // 
            end.AutoSize = true;
            end.Location = new Point(90, 125);
            end.Name = "end";
            end.Size = new Size(38, 15);
            end.TabIndex = 2;
            end.Text = "label3";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 47);
            label1.Name = "label1";
            label1.Size = new Size(72, 15);
            label1.TabIndex = 3;
            label1.Text = "Event name:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 91);
            label2.Name = "label2";
            label2.Size = new Size(61, 15);
            label2.TabIndex = 4;
            label2.Text = "Start time:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 125);
            label3.Name = "label3";
            label3.Size = new Size(57, 15);
            label3.TabIndex = 5;
            label3.Text = "End time:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 156);
            label4.Name = "label4";
            label4.Size = new Size(56, 15);
            label4.TabIndex = 6;
            label4.Text = "Duration:";
            // 
            // duration
            // 
            duration.AutoSize = true;
            duration.Location = new Point(90, 156);
            duration.Name = "duration";
            duration.Size = new Size(38, 15);
            duration.TabIndex = 7;
            duration.Text = "label5";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(252, 47);
            label5.Name = "label5";
            label5.Size = new Size(70, 15);
            label5.TabIndex = 8;
            label5.Text = "Description:";
            // 
            // description
            // 
            description.AutoSize = true;
            description.Location = new Point(121, 156);
            description.Name = "description";
            description.Size = new Size(0, 15);
            description.TabIndex = 9;
            // 
            // descBox
            // 
            descBox.Location = new Point(251, 65);
            descBox.Multiline = true;
            descBox.Name = "descBox";
            descBox.ReadOnly = true;
            descBox.ScrollBars = ScrollBars.Vertical;
            descBox.Size = new Size(235, 41);
            descBox.TabIndex = 10;
            // 
            // editButton
            // 
            editButton.Font = new Font("Segoe UI", 12F);
            editButton.Location = new Point(11, 177);
            editButton.Name = "editButton";
            editButton.Size = new Size(235, 83);
            editButton.TabIndex = 11;
            editButton.Text = "Edit";
            editButton.UseVisualStyleBackColor = true;
            editButton.Click += editButton_Click;
            // 
            // deleteButton
            // 
            deleteButton.Font = new Font("Segoe UI", 12F);
            deleteButton.ForeColor = Color.Red;
            deleteButton.Location = new Point(251, 177);
            deleteButton.Name = "deleteButton";
            deleteButton.Size = new Size(235, 83);
            deleteButton.TabIndex = 12;
            deleteButton.Text = "Delete";
            deleteButton.UseVisualStyleBackColor = true;
            deleteButton.Click += deleteButton_Click;
            // 
            // backButton
            // 
            backButton.ForeColor = Color.Red;
            backButton.Location = new Point(411, 12);
            backButton.Name = "backButton";
            backButton.Size = new Size(75, 23);
            backButton.TabIndex = 22;
            backButton.Text = "Back";
            backButton.UseVisualStyleBackColor = true;
            backButton.Click += backButton_Click;
            // 
            // eventDetails
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(498, 265);
            Controls.Add(backButton);
            Controls.Add(deleteButton);
            Controls.Add(editButton);
            Controls.Add(descBox);
            Controls.Add(description);
            Controls.Add(label5);
            Controls.Add(duration);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(end);
            Controls.Add(start);
            Controls.Add(name);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "eventDetails";
            Text = "Event Details";
            Load += eventDetails_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label name;
        private Label start;
        private Label end;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label duration;
        private Label label5;
        private Label description;
        private TextBox descBox;
        private Button editButton;
        private Button deleteButton;
        private Button backButton;
    }
}