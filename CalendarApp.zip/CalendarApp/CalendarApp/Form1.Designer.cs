﻿namespace CalendarApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            addEventButton = new Button();
            viewCalendarButton = new Button();
            SuspendLayout();
            // 
            // addEventButton
            // 
            addEventButton.Font = new Font("Segoe UI", 12F);
            addEventButton.Location = new Point(12, 320);
            addEventButton.Name = "addEventButton";
            addEventButton.Size = new Size(375, 118);
            addEventButton.TabIndex = 0;
            addEventButton.Text = "Add Event";
            addEventButton.UseVisualStyleBackColor = true;
            addEventButton.Click += addEventButton_Click;
            // 
            // viewCalendarButton
            // 
            viewCalendarButton.Font = new Font("Segoe UI", 12F);
            viewCalendarButton.Location = new Point(413, 320);
            viewCalendarButton.Name = "viewCalendarButton";
            viewCalendarButton.Size = new Size(375, 118);
            viewCalendarButton.TabIndex = 1;
            viewCalendarButton.Text = "View Calendar";
            viewCalendarButton.UseVisualStyleBackColor = true;
            viewCalendarButton.Click += viewCalendarButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(viewCalendarButton);
            Controls.Add(addEventButton);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "Form1";
            Text = "Calendar";
            Load += Form1_Load;
            ResumeLayout(false);
        }

        #endregion

        private Button addEventButton;
        private Button viewCalendarButton;
    }
}
