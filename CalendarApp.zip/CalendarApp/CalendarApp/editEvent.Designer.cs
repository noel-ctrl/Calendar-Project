﻿namespace CalendarApp
{
    partial class editEvent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            eventTitle = new Label();
            label3 = new Label();
            eventTitleBox = new TextBox();
            descriptionBox = new TextBox();
            label1 = new Label();
            label2 = new Label();
            startTime = new DateTimePicker();
            endTime = new DateTimePicker();
            label4 = new Label();
            label5 = new Label();
            chosenStartDay = new Label();
            chosenEndDay = new Label();
            confirmButton = new Button();
            backButton = new Button();
            SuspendLayout();
            // 
            // eventTitle
            // 
            eventTitle.AutoSize = true;
            eventTitle.Location = new Point(18, 47);
            eventTitle.Name = "eventTitle";
            eventTitle.Size = new Size(64, 15);
            eventTitle.TabIndex = 7;
            eventTitle.Text = "Event Title:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(251, 47);
            label3.Name = "label3";
            label3.Size = new Size(70, 15);
            label3.TabIndex = 9;
            label3.Text = "Description:";
            // 
            // eventTitleBox
            // 
            eventTitleBox.Location = new Point(18, 65);
            eventTitleBox.Name = "eventTitleBox";
            eventTitleBox.Size = new Size(227, 23);
            eventTitleBox.TabIndex = 10;
            // 
            // descriptionBox
            // 
            descriptionBox.Location = new Point(251, 65);
            descriptionBox.MaxLength = 200;
            descriptionBox.Multiline = true;
            descriptionBox.Name = "descriptionBox";
            descriptionBox.ScrollBars = ScrollBars.Vertical;
            descriptionBox.Size = new Size(225, 41);
            descriptionBox.TabIndex = 11;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(18, 119);
            label1.Name = "label1";
            label1.Size = new Size(63, 15);
            label1.TabIndex = 12;
            label1.Text = "Start Time:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(251, 119);
            label2.Name = "label2";
            label2.Size = new Size(59, 15);
            label2.TabIndex = 13;
            label2.Text = "End Time:";
            // 
            // startTime
            // 
            startTime.Format = DateTimePickerFormat.Time;
            startTime.Location = new Point(18, 137);
            startTime.Name = "startTime";
            startTime.Size = new Size(227, 23);
            startTime.TabIndex = 14;
            startTime.ValueChanged += startTime_ValueChanged;
            // 
            // endTime
            // 
            endTime.Format = DateTimePickerFormat.Time;
            endTime.Location = new Point(251, 137);
            endTime.Name = "endTime";
            endTime.Size = new Size(225, 23);
            endTime.TabIndex = 15;
            endTime.ValueChanged += endTime_ValueChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(18, 172);
            label4.Name = "label4";
            label4.Size = new Size(77, 15);
            label4.TabIndex = 16;
            label4.Text = "Chosen Start:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(251, 172);
            label5.Name = "label5";
            label5.Size = new Size(73, 15);
            label5.TabIndex = 17;
            label5.Text = "Chosen End:";
            // 
            // chosenStartDay
            // 
            chosenStartDay.AutoSize = true;
            chosenStartDay.Location = new Point(101, 172);
            chosenStartDay.Name = "chosenStartDay";
            chosenStartDay.Size = new Size(38, 15);
            chosenStartDay.TabIndex = 18;
            chosenStartDay.Text = "label6";
            // 
            // chosenEndDay
            // 
            chosenEndDay.AutoSize = true;
            chosenEndDay.Location = new Point(330, 172);
            chosenEndDay.Name = "chosenEndDay";
            chosenEndDay.Size = new Size(38, 15);
            chosenEndDay.TabIndex = 19;
            chosenEndDay.Text = "label7";
            // 
            // confirmButton
            // 
            confirmButton.BackColor = SystemColors.Control;
            confirmButton.FlatStyle = FlatStyle.System;
            confirmButton.Font = new Font("Segoe UI", 12F);
            confirmButton.ForeColor = SystemColors.Control;
            confirmButton.Location = new Point(18, 206);
            confirmButton.Name = "confirmButton";
            confirmButton.Size = new Size(458, 47);
            confirmButton.TabIndex = 20;
            confirmButton.Text = "Confirm Changes";
            confirmButton.UseVisualStyleBackColor = false;
            confirmButton.Click += confirmButton_Click;
            // 
            // backButton
            // 
            backButton.ForeColor = Color.Red;
            backButton.Location = new Point(407, 9);
            backButton.Name = "backButton";
            backButton.Size = new Size(75, 23);
            backButton.TabIndex = 21;
            backButton.Text = "Back";
            backButton.UseVisualStyleBackColor = true;
            backButton.Click += backButton_Click;
            // 
            // editEvent
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(494, 265);
            Controls.Add(backButton);
            Controls.Add(confirmButton);
            Controls.Add(chosenEndDay);
            Controls.Add(chosenStartDay);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(endTime);
            Controls.Add(startTime);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(descriptionBox);
            Controls.Add(eventTitleBox);
            Controls.Add(label3);
            Controls.Add(eventTitle);
            Name = "editEvent";
            Text = "Edit Event";
            Load += editEvent_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label eventTitle;
        private Label label3;
        public TextBox eventTitleBox;
        public TextBox descriptionBox;
        private Label label1;
        private Label label2;
        public DateTimePicker startTime;
        public DateTimePicker endTime;
        private Label label4;
        private Label label5;
        private Label chosenStartDay;
        private Label chosenEndDay;
        public Button confirmButton;
        private Button backButton;
    }
}