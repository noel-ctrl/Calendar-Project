namespace CalendarApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.CenterToScreen();
        }

        private void addEventButton_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            this.Hide();
            addForm.ShowDialog();
            this.Show();
        }

        private void viewCalendarButton_Click(object sender, EventArgs e)
        {
            Form3 viewForm = new Form3();
            this.Hide();
            viewForm.ShowDialog();
            this.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
