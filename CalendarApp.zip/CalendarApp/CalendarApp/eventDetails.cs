﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CalendarApp
{
    public partial class eventDetails : Form
    {

        DateTime st;
        DateTime en;
        string n;
        string desc;
        int eventId;

        public eventDetails(int id)
        {
            InitializeComponent();
            this.CenterToScreen();
            eventId = id;
            showEventDetails();
        }

        void showEventDetails()
        {

            string connStr = "server=csitmariadb.eku.edu;user=student;database=csc340_db;port=3306;password=Maroon@21?";
            MySqlConnection conn = new MySqlConnection(connStr);
            conn.Open();
            string q = "SELECT Name, Start, End, Description FROM noelFeltnerReichert_calendarNew WHERE ID = @EventId";

            MySqlCommand cmd = new MySqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@EventId", eventId);
            MySqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                n = reader.GetString("Name");
                name.Text = n;
                start.Text = reader.GetDateTime("Start").ToString("MMM dd, yyyy hh:mm:ss tt");
                end.Text = reader.GetDateTime("End").ToString("MMM dd, yyyy hh:mm:ss tt");
                st = reader.GetDateTime("Start");
                en = reader.GetDateTime("End");
                TimeSpan dur = en - st;
                int hours = (int)dur.TotalHours;
                int minutes = (int)dur.TotalMinutes % 60;
                int seconds = dur.Seconds;
                duration.Text = $"{hours} hours, {minutes} minutes and {seconds} seconds.";
                desc = reader.GetString("Description");
                descBox.Text = desc;
            }
        }

        private void editButton_Click(object sender, EventArgs e)
        {

            editEvent edit = new editEvent(eventId, st, en, n, desc);
            this.Hide();
            edit.ShowDialog();
            this.Show();
            showEventDetails();
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            string connStr = "server=csitmariadb.eku.edu;user=student;database=csc340_db;port=3306;password=Maroon@21?";
            MySqlConnection conn = new MySqlConnection(connStr);
            conn.Open();

            DialogResult confirmDelete = MessageBox.Show("Are you sure you want to delete this event?", "Confirm Delete", MessageBoxButtons.YesNo);

            if (confirmDelete == DialogResult.Yes)
            {
                string q = "DELETE FROM noelFeltnerReichert_calendarNew WHERE ID = @EventId";
                MySqlCommand cmd = new MySqlCommand(q, conn);

                cmd.Parameters.AddWithValue("@EventId", eventId);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Event successfully deleted.");
            }
            else
            {
                MessageBox.Show("Event not deleted.");
            }
            this.Close();
        }

        void deleteEvent(int eventId)
        {

        }

        private void eventDetails_Load(object sender, EventArgs e)
        {

        }

        private void backButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
