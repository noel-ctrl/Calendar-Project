﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CalendarApp
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            this.CenterToScreen();
            chosenStartDay.Text = DateTime.Now.ToString();
            chosenEndDay.Text = DateTime.Now.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void startTime_ValueChanged(object sender, EventArgs e)
        {
            chosenStartDay.Text = startTime.Value.ToString("MMM dd, yyyy hh:mm:ss tt");
        }

        private void endTime_ValueChanged(object sender, EventArgs e)
        {
            chosenEndDay.Text = endTime.Value.ToString("MMM dd, yyyy hh:mm:ss tt");
        }

        private void addToCalendarButton_Click(object sender, EventArgs e)
        {

            string connStr = "server=csitmariadb.eku.edu;user=student;database=csc340_db;port=3306;password=Maroon@21?";


            MySql.Data.MySqlClient.MySqlConnection conn = new MySql.Data.MySqlClient.MySqlConnection(connStr);

            conn.Open();

            if (endTime.Value <= startTime.Value && String.IsNullOrEmpty(eventTitleBox.Text))
            {
                MessageBox.Show("End time must be greater than start time.\nEvent must have title.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            if (endTime.Value <= startTime.Value)
            {
                MessageBox.Show("End time must be greater than start time.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            if (String.IsNullOrEmpty(eventTitleBox.Text))
            {
                MessageBox.Show("Event must have title.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }


            else
            {
                //check if there are any event collisions
                //if there are collisions, tell them what they are and ask them to change details

                //ask if they want to save the event
                string eventName = eventTitleBox.Text;
                string start = startTime.Value.ToString("t");
                string startDay = startTime.Value.ToString("d");
                string end = endTime.Value.ToString("t");
                string endDay = endTime.Value.ToString("d");
                TimeSpan dur = endTime.Value - startTime.Value;
                int hours = (int)dur.TotalHours;
                int minutes = dur.Minutes;
                int seconds = dur.Seconds;

                //sql to check if there are collisions
                string query = @"SELECT Name, Start, End FROM noelFeltnerReichert_calendarNew
                                WHERE NOT (`Start` >= @NewEventEnd OR `End` <= @NewEventStart)";
                DateTime st = startTime.Value;
                DateTime en = endTime.Value;
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@NewEventStart", st);
                cmd.Parameters.AddWithValue("@NewEventEnd", en);

                string overlapping = null;
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        if (overlapping == null)
                            overlapping = "";
                        overlapping += ($"Event: {reader["Name"]}, Start: {Convert.ToDateTime(reader["Start"]).ToString("g")}, End: {Convert.ToDateTime(reader["End"]).ToString("g")}\n");
                    }
                }

                if (!string.IsNullOrEmpty(overlapping))
                {
                    MessageBox.Show($"Cannot add event due to overlapping with the following event(s):\n{overlapping}", "Scheduling Conflict", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string message = $"Event Name: {eventName}\nStart Time: {startDay} {start}\nEnd Time: {endDay} {end}\nDuration: {hours} hours, {minutes} minutes and {seconds} seconds.\n\nDo you want to confirm this event?";
                DialogResult confirmEvent = MessageBox.Show(message, "Confirm Event", MessageBoxButtons.YesNo);

                if (confirmEvent == DialogResult.Yes)
                {
                    string insertQuery = @"INSERT INTO noelFeltnerReichert_calendarNew (Name, Start, End, Description) 
                               VALUES (@Name, @Start, @End, @Description)";
                    MySqlCommand cma = new MySqlCommand(insertQuery, conn);
                    cma.Parameters.AddWithValue("@Name", eventName);
                    cma.Parameters.AddWithValue("@Start", st);
                    cma.Parameters.AddWithValue("@End", en);
                    cma.Parameters.AddWithValue("@Description", descriptionBox.Text);
                    cma.ExecuteNonQuery();
                    conn.Close();

                    //close the window after successfully saved
                    MessageBox.Show("Event successfully saved.");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Event not confirmed.");
                }
            }

        }

        private void eventTitleBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void descriptionBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void backButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
